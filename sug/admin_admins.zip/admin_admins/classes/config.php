

<?php
define("DB_HOST", "campaignmedia.com.ng");
define("DB_USER", "campaig3");
define("DB_PASS", "6Lz8E5LNe!7cz]");
define("DB_NAME", "campaig3_flier");
// "campaignmedia.com.ng","campaig3","6Lz8E5LNe!7cz]","campaig3_flier"
?>