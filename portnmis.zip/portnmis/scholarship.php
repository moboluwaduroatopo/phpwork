
<body>
<!-- <div class="spinner-border" role="status">
  <span class="sr-only">Loading...</span>
</div> -->
  <!-- Navbar -->
 <?php include 'nav.php';?>
  <!-- Navbar -->



  <!-- Full Page Intro -->
  <div class="view" style="background-image: url('img/6.jpg'); background-repeat: no-repeat; background-size: cover;height: 400px">

    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">

            <!-- Content -->
            <div class="text-center white-text mx-5 wow fadeIn">
              <h1 class="mb-4">
                <strong>Scholarship</strong>
              </h1>
            </div>
            <!-- Content -->

          </div>

  </div>
  <!-- Full Page Intro -->

  <!--Main layout-->
  <main>
    
    <div class="container">
   
      <!--Section: Not enough-->

      <hr class="mb-5">

      <!--Section: More-->
      <section>

        <h3 class="h3 text-center mb-5">Coming Soon.....................</h3>

        <!--Grid row-->
        <div class="row wow fadeIn">
</div>

      </section>
      <!--Section: More-->
   
      <section>
   <?php include 'people.php';?>
      </section>
    </div>
  </main>
  <!--Main layout-->

  <!--Footer-->
  <footer class="page-footer text-center font-small mt-4 wow fadeIn">

    <!--Call to action-->
  
    <!-- Social icons -->

    <!--Copyright-->
    <div class="footer-copyright py-3">
      © 2019 Copyright:
      <a href="motee.com.ng" target="_blank"> motee.com.ng</a>
    </div>
    <!--/.Copyright-->

  </footer>
  <!--/.Footer-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Initializations -->
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();
  </script>
</body>

</html>
