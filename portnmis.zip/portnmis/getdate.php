<?php

//mjk


$re = array('success' => true, "data"=>date("y-m-d h:i:s"));
echo json_encode($re);
?>