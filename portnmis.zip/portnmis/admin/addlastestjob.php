 <form class='text-center border border-light p-5' method='POST'  action='formlastest.php'>

    <p class='h4 mb-4'>Add Lastest Opp</p>

      <input type='text' id='defaultContactFormName' class='form-control mb-4' placeholder='Titlt Name' name='title_name'>
    <div class='form-group'>
        <textarea class='form-control rounded-0' id='exampleFormControlTextarea2' rows='3' placeholder='Content' name='content'></textarea>
    </div>
      <input type='text' id='defaultContactFormName' class='form-control mb-4' placeholder='Enter link name' name='link_name'>
      <input type='text' id='defaultContactFormName' class='form-control mb-4' placeholder='Delinedate' name='dates'>
    
    <button class='btn btn-info btn-block' type='submit' name='submit'>Save</button>

</form>