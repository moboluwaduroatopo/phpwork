
<?php
define("DB_HOST", "daudamonsuru.com.ng");
define("DB_USER", "daudamon");
define("DB_PASS", "1WN7b]Wa8k:Xu0");
define("DB_NAME", "daudamon_nmis.db");

?>