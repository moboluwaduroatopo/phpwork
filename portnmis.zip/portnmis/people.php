 <h2 class="my-5 h3 text-center">PEOPLE SAYS...</h2>

        <!--First row-->
        <div class="row features-small mb-5 mt-3 wow fadeIn">

          <!--First column-->
          <div class="col-md-4">
            <!--First row-->
            <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div>
            <!--/First row-->

            <!--Second row-->
            <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div>
            <!--/Second row-->

            <!--Third row-->
            <!-- <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div> -->
            <!--/Third row-->

            <!--Fourth row-->
         <!--    <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Fully responsive</h6>
                <p class="grey-text">It doesn't matter whether your project will be displayed on desktop, laptop, tablet or mobile phone. MDB
                  looks great on each screen.</p>
                <div style="height:15px"></div>
              </div>
            </div> -->
            <!--/Fourth row-->
          </div>
          <!--/First column-->

          <!--Second column-->
          <div class="col-md-4 flex-center">
            <img src="https://mdbootstrap.com/img/Others/screens.png" alt="" class="z-depth-0 img-fluid">
          </div>
          <!--/Second column-->

          <!--Third column-->
          <div class="col-md-4 mt-2">
            <!--First row-->
            <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div>
            <!--/First row-->

            <!--Second row-->
            <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div>
            <!--/Second row-->

            <!--Third row-->
           <!--  <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Hi. I’m MOTEE, a software engineer.</h6>
                <p class="grey-text">I am passionate about building excellent software that improves the lives of those around me. I specialize in creating software for clients ranging from individuals and small-businesses all the way to large enterprise corporations. And,  I always deliver quality services in a timely fashion to help my clients gain a leading edge in this competitive market.
                </p>
                <div style="height:15px"></div>
              </div>
            </div> -->
            <!--/Third row-->

            <!--Fourth row-->
           <!--  <div class="row">
              <div class="col-2">
                <i class="fas fa-check-circle fa-2x indigo-text"></i>
              </div>
              <div class="col-10">
                <h6 class="feature-title">Easy to use and customize</h6>
                <p class="grey-text">Using MDB is straightforward and pleasant. Components flexibility allows you deep customization. You will
                  easily adjust each component to suit your needs.</p>
                <div style="height:15px"></div>
              </div>
            </div> -->
            <!--/Fourth row-->
          </div>
          <!--/Third column-->

        </div>